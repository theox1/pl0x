=== Change WordPress Login Logo ===
Contributors: boopathi0001
Donate link: https://paypal.me/boopathirajan
Tags: WordPress Logo change, Login Logo, Custom logo, WP admin logo, Change default logo
Requires at least: 4.3
Tested up to: 5.8.1
Requires PHP: 5.2.4
Stable tag: 1.1.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Upload your logo for WordPress login page instead of the usual WordPress logo with simple settings.

== Description ==

Upload your logo for WordPress login page instead of the usual WordPress logo with simple settings.

Video Tutorial:

https://www.youtube.com/watch?v=Iu-XlWjyR9o

Kindly let us know your feedback or comments to add more features in this plugin.

== Installation ==

1. Log in to your WordPress admin panel and go to Plugins -> Add New
2. Type **Change WordPress Login Logo** in the search box and click on search button.
3. Find Change WordPress Login Logo plugin.
4. Then click on Install Now after that activate the plugin.

== Frequently Asked Questions ==

= How to configure Change WordPress Login Logo Plugin? =

1. Click "Settings" tab from left navigation menu:
2. Click "Login Logo" menu under the Settings menu
3. Upload new login logo using WP media uploader.
4. Click "Save Changes" button to save the configuration details.